from __future__ import absolute_import

from celery import Celery



celery = Celery('videodl',
             broker='amqp://guest@localhost//',

             )

