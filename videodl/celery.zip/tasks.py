# Create your tasks here

from videodl.celery import celery
from . celery import task 


@task(name='tasks.add')
def add(x, y):
    print (x)
    return x + y


